package org.example;

import org.apache.lucene.queryparser.classic.ParseException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class SearchController {

    private final LuceneSearcher luceneSearcher;

    public SearchController() throws IOException {
        this.luceneSearcher = new LuceneSearcher();
    }

    @GetMapping("/search")
    public List<Map<String, String>> search(
            @RequestParam String queryText,
            @RequestParam(required=false, defaultValue="body") String field,
            @RequestParam(required = false, defaultValue = "term") String queryType)
    {
        List<Map<String, String>> resultsList = new ArrayList<>();
        try {
            List<Map<String, String>> docs = luceneSearcher.search( field, queryText, queryType);
            for (Map<String, String> doc : docs) {
                Map<String, String> result = new HashMap<>();
                result.put("title", doc.get("title"));
                result.put("abstract", doc.get("abstract"));
                result.put("body", doc.get("body"));
                result.put("authors", doc.get("authors"));
                result.put("bibliography", doc.get("bibliography"));
                resultsList.add(result);
            }
        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
        return resultsList;
    }
}
