package org.example;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.core.WhitespaceTokenizerFactory;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.analysis.miscellaneous.WordDelimiterGraphFilterFactory;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.codecs.simpletext.SimpleTextCodec;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class HTMLIndexer {

    private static final String HTML_FILES_DIR = "/Users/alicececot/Desktop/ingegneria dei dati/urls_htmls_tables/all_htmls";
    private static final String INDEX_DIR = "index";

    public static void main(String[] args) {
        int documentCount = 0;

        long startTime = System.currentTimeMillis();

        try {
            Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));

            Map<String, Analyzer> perFieldAnalyzers = new HashMap<>();
            perFieldAnalyzers.put("title", myAnalyzer());
            perFieldAnalyzers.put("authors", myAnalyzer());

            Analyzer perFieldAnalyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer(), perFieldAnalyzers);

            IndexWriterConfig config = new IndexWriterConfig(perFieldAnalyzer);
            config.setCodec(new SimpleTextCodec());
            config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);
            IndexWriter writer = new IndexWriter(directory, config);

            File htmlDir = new File(HTML_FILES_DIR);
            if (htmlDir.isDirectory()) {
                for (File file : htmlDir.listFiles((dir, name) -> name.endsWith(".html"))) {
                    indexHtmlFile(writer, file);
                    documentCount++;
                }
            }

            writer.commit();
            writer.close();

            long endTime = System.currentTimeMillis();

            long duration = endTime - startTime;
            double durationInSeconds = duration / 1000.0;

            System.out.println("Number of indexed documents: " + documentCount);
            System.out.println("Total indexing time: " + durationInSeconds + " second");
            double averageIndexingTimePerDocument = documentCount > 0 ? (durationInSeconds / documentCount) : 0;
            System.out.println("Average total indexing per document: " + averageIndexingTimePerDocument + " second");


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void indexHtmlFile(IndexWriter writer, File file) throws IOException {
        org.jsoup.nodes.Document jsoupDoc = Jsoup.parse(file, "UTF-8");

        String title = jsoupDoc.title();
        String abstractText = getAbstractContent(jsoupDoc);
        String body = jsoupDoc.body().text();
        String bibliography = getBibliographyContent(jsoupDoc);
        String author = getAuthorContent(jsoupDoc);

        Document doc = new Document();
        doc.add(new TextField("title", title, Field.Store.YES));
        doc.add(new TextField("abstract", abstractText, Field.Store.YES));
        doc.add(new TextField("body", body, Field.Store.YES));
        doc.add(new TextField("bibliography", bibliography, Field.Store.YES));
        doc.add(new TextField("authors", author, Field.Store.YES));

        writer.addDocument(doc);
    }

    private static Analyzer myAnalyzer() throws IOException {
        return CustomAnalyzer.builder()
                .withTokenizer(WhitespaceTokenizerFactory.class)
                .addTokenFilter(LowerCaseFilterFactory.class)
                .addTokenFilter(WordDelimiterGraphFilterFactory.class)
                .build();
    }

    private static String getAbstractContent(org.jsoup.nodes.Document jsoupDoc) {
        Element abstractElement = jsoupDoc.selectFirst("div.ltx_abstract");
        return abstractElement != null ? abstractElement.text() : "";
    }

    private static String getAuthorContent(org.jsoup.nodes.Document jsoupDoc) {
        Element authorElement = jsoupDoc.selectFirst("div.ltx_authors");
        return authorElement != null ? authorElement.text() : "";
    }

    private static String getBibliographyContent(org.jsoup.nodes.Document jsoupDoc) {
        Element bibliographyElement = jsoupDoc.selectFirst("section.ltx_bibliography");
        return bibliographyElement != null ? bibliographyElement.text() : "";
    }
}
