package org.example;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.core.WhitespaceTokenizerFactory;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.miscellaneous.WordDelimiterGraphFilterFactory;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LuceneSearcher {

    private static final String INDEX_DIR = "index";
    private final IndexSearcher searcher;
    private final Analyzer analyzer;

    public LuceneSearcher() throws IOException {
        Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));
        IndexReader reader = DirectoryReader.open(directory);
        this.searcher = new IndexSearcher(reader);

        this.searcher.setSimilarity(new BM25Similarity());

        Map<String, Analyzer> perFieldAnalyzers = new HashMap<>();
        perFieldAnalyzers.put("title", myAnalyzer());
        perFieldAnalyzers.put("authors", myAnalyzer());

        this.analyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer(), perFieldAnalyzers);
    }

    private Analyzer myAnalyzer() throws IOException {
        return CustomAnalyzer.builder()
                .withTokenizer(WhitespaceTokenizerFactory.class)
                .addTokenFilter(LowerCaseFilterFactory.class)
                .addTokenFilter(WordDelimiterGraphFilterFactory.class)
                .build();
    }

    public Analyzer getAnalyzer() {
        return this.analyzer;
    }

    public List<Map<String, String>> search(String field, String queryText, String queryType) throws ParseException, IOException {
        Query query = buildQuery(field, queryText, queryType);
        TopDocs results = searcher.search(query, 50);

        List<Map<String, String>> resultsList = new ArrayList<>();

        int count = 0;
        for (ScoreDoc scoreDoc : results.scoreDocs) {
            Document doc = searcher.doc(scoreDoc.doc);
            float score = scoreDoc.score;
            if (count < 10) {
                System.out.println("Similarity Score: " + score + "- Documento: " + doc.get("title"));
            }
            count++;

            Map<String, String> result = new HashMap<>();

            if ("all".equals(field)) {
                String[] fields = {"title", "abstract", "body", "authors", "bibliography"};
                for (String singleField : fields) {
                    result.put(singleField, doc.get(singleField));
                }
            } else {
                String text = doc.get(field);
                if (text != null) {
                    result.put(field, text);
                }
            }

            for (String key : new String[]{"title", "abstract", "body", "authors", "bibliography"}) {
                result.putIfAbsent(key, doc.get(key));
            }

            resultsList.add(result);
        }
        return resultsList;
    }

    private Query buildQuery(String field, String queryText, String queryType) throws ParseException {
        if ("all".equals(field)) {
            BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
            String[] fields = {"title", "abstract", "body", "authors", "bibliography"};

            for (String singleField : fields) {
                Query singleFieldQuery;
                switch (queryType.toLowerCase()) {
                    case "term":
                        singleFieldQuery = new TermQuery(new Term(singleField, queryText));
                        break;
                    case "phrase":
                        PhraseQuery.Builder phraseBuilder = new PhraseQuery.Builder();
                        for (String term : queryText.split(" ")) {
                            phraseBuilder.add(new Term(singleField, term));
                        }
                        singleFieldQuery = phraseBuilder.build();
                        break;
                    case "prefix":
                        singleFieldQuery = new PrefixQuery(new Term(singleField, queryText));
                        break;
                    default:
                        QueryParser parser = new QueryParser(singleField, analyzer);
                        singleFieldQuery = parser.parse(queryText);
                }
                booleanQuery.add(singleFieldQuery, BooleanClause.Occur.SHOULD);
            }
            return booleanQuery.build();
        } else {
            switch (queryType.toLowerCase()) {
                case "term":
                    return new TermQuery(new Term(field, queryText));
                case "phrase":
                    PhraseQuery.Builder phraseBuilder = new PhraseQuery.Builder();
                    for (String term : queryText.split(" ")) {
                        phraseBuilder.add(new Term(field, term));
                    }
                    return phraseBuilder.build();
                case "prefix":
                    return new PrefixQuery(new Term(field, queryText));
                default:
                    QueryParser parser = new QueryParser(field, analyzer);
                    return parser.parse(queryText);
            }
        }
    }
}
